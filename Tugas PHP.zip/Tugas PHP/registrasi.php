<?php
require 'functions.php';
// Koneksi ke database

if(isset($_POST["register"])){
    if(registrasi ($_POST) > 0 ){
        echo "<script>
        alert('user baru berhasil ditambahkan !');
        </script>";
        // Redirect ke halaman login setelah registrasi berhasil
        header("Location: login.php");
        exit;

    } else {
       echo mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Registrasi</title>
    <!-- Tautan ke Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Gaya kustom -->
    <style>
        body {
            background-color: #f5f5f5;
        }
        .form-register {
            width: 100%;
            max-width: 330px;
            padding: 15px;
            margin: auto;
        }
        .form-register .form-control {
            position: relative;
            box-sizing: border-box;
            height: auto;
            padding: 10px;
            font-size: 16px;
        }
        .form-register input[type="text"],
        .form-register input[type="password"] {
            margin-bottom: 25px;
        }
        .form-register input[type="text"] {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }
        .form-register input[type="password"] {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }
        .form-register button[type="submit"] {
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form class="form-register" action="" method="post">
                    <h1 class="h3 mb-3 font-weight-normal">Halaman Registrasi</h1>
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" name="username" id="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                    <div class="form-group">
                        <label for="password2">Konfirmasi Password:</label>
                        <input type="password" class="form-control" name="password2" id="password2">
                    </div>
                    <button type="submit" class="btn btn-primary" name="register">Register</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
