<?php
session_start();

//cek cookie
if (isset($_COOKIE['id'])&& isset($_COOKIE['key'])){
    $id= $_COOKIE['id'];
    $key= $_COOKIE['key'];

    //mengambil username berdasarkan id
    $result= mysqli_query($con,"SELECT username FROM users WHERE id =$id");
    $row = mysqli_fetch_assoc($result);

    //cek cookie dan username
    if($key === hash('sha256', $row['username'])){
        $_SESSION['login']= true;
    }
} 

if (isset($_SESSION["login"]) ){
    header("Location: index.php");
    exit;
}

require 'functions.php';

if(isset($_POST["login"])){

    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn,"SELECT * FROM users WHERE username = '$username'");

    //cek username
    if(mysqli_num_rows($result) === 1){

        //cek password
        $row = mysqli_fetch_assoc($result);
        if(password_verify($password, $row["password"])){
            //cek session
            $_SESSION["login"] = true;

            //cek remember me
            if (isset($_POST["remember"])){
                //buat cookie
                setcookie('id', $row['id'], time()+60);
                setcookie('key',hash('sha256', $row['username']), time()+ 60);
            }
            $id = $row["id"];
            header("Location: index.php?ID=$id");
            exit;
        }
    }
    $error = true;

}
?>

<!DOCTYPE html>
<html >
<head>
    <title>Halaman Login</title>
    <!-- Tautan ke Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Gaya kustom -->
    <style>
        body {
            /* Membuat latar belakang gambar */
            background-image:url('1.jpg.gif');
            background-size: cover;
             /
             /*Warna teks agar terlihat jelas di atas latar belakang */
            color: #fff; 
        }
        .form-signin {
            width: 100%;
            max-width: 330px;
            padding: 15px;
            margin: auto;
        }
        .form-signin .checkbox {
            font-weight: 400;
        }
        .form-signin .form-control {
            position: relative;
            box-sizing: border-box;
            height: auto;
            padding: 10px;
            font-size: 16px;
        }
        .form-signin .form-control:focus {
            z-index: 2;
        }
        .form-signin input[type="text"] {
            margin-bottom: 25px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
        }
        .form-signin input[type="password"] {
            margin-bottom: 25px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }
        .discussion-img {
            width: 100%;
            max-width: 400px;
            display: block;
            margin: auto;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form class="form-signin" action="" method="post">
                    <h1 class="h3 mb-3 font-weight-normal">Halaman Login</h1>
                    <?php if (isset($error)): ?>
                        <p style="color: red; font-style: italic;">Username atau password salah</p>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" class="form-control" name="username" id="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="password" id="password">
                    </div>
                    <button type="submit" class="btn btn-primary" name="login">Login</button>
                    <p class="mt-3">Belum punya akun? <a href="registrasi.php">Daftar sekarang</a></p>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
