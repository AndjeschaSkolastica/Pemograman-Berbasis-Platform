<?php
session_start();

if (!isset($_SESSION["login"])){
    header("Location: login.php");
    exit;
}

$id = $_GET["ID"];

require 'functions.php';

// Proses tambah tugas
if (isset($_POST['tambah'])) {
    $list = $_POST['list'];
    tambah($list, $id);
    header("Location: index.php?ID=$id");
    exit;
}

// Proses tanda selesai tugas
if (isset($_GET['selesai'])) {
    $id = $_GET['selesai'];
    ubahStatus($id);
    header("Location: index.php?ID=$id");
    exit;
}

// Proses hapus tugas
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    hapus($id);
    header("Location: index.php?ID=$id");
    exit;
}

// Ambil semua tugas
$todos = mysqli_query($conn, "SELECT * FROM todo");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />

    <title>ToDo List</title>
</head>
<body>
    <h1>ToDo List</h1>
    <form action="" method="post">
        <input type="text" name="list" placeholder="Tambah tugas" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <ul>
        <?php while ($row = mysqli_fetch_assoc($todos)) : ?>
            
                <?php if ($row['status'] == "aktif") { ?>
                    <?php echo $row['list']; ?>
                <?php } else { ?>
                    <s><?php echo $row['list']; ?></s>
                <?php } ?>
                <a href="?selesai=<?php echo $row['id']; ?>">Selesai</a>
                <a href="?hapus=<?php echo $row['id']; ?>">Hapus</a>
                
        <?php endwhile; ?>
    </ul>
    <a href="logout.php">Logout</a>
</body>
</html>